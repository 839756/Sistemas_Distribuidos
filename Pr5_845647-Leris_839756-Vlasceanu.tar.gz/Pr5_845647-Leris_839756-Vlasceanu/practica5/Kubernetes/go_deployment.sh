kubectl delete deploy/de
kubectl delete service miservicio
kubectl create -f deploy_go.yaml
