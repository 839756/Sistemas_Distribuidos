kubectl delete statefulset ss
kubectl delete pod cc
kubectl delete service ss-service
kubectl create -f statefulset_go.yaml
